package M10.D05;

public class Main {
    public static void main(String[] args){
        // MyThread thread0 = new MyThread();
        // MyThread thread1 = new MyThread();
        // thread0.setDaemon(true);
        // thread1.setDaemon(true);
        // thread0.start();
        // thread1.start();
        // // Tool tool = new Tool();
        // // tool.method1();
        System.err.println("HelloWorld");
    }
}
